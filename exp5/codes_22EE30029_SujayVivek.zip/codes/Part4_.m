% Load pcm data
load pcm.mat; % Assumes pcm is the signal variable name
fs = 8000; % Sampling frequency in Hz
mod_freq = 3146; % Modulation frequency in Hz
theta = 2 * pi * (mod_freq / fs); % Calculate theta

% Plot time domain samples for indices 100 to 200
figure;
subplot(2, 1, 1);
plot(100:200, pcm(100:200));
title('Original pcm Signal (Time Domain)');
xlabel('Sample Index');
ylabel('Amplitude');
grid on;
    set(gca, 'FontSize', 15);


% Calculate and plot DTFT for the original pcm signal over indices 100 to 1100
N = 1001; % Number of samples
[X, w] = DTFT(pcm(100:1100), N); % Using previously defined DTFT function
subplot(2, 1, 2);
plot(w, abs(X));
title('Magnitude of DTFT for Original Signal');
xlabel('Frequency (rad/sample)');
ylabel('|X(\omega)|');
xlim([-pi pi]);
grid on;
    set(gca, 'FontSize', 15);

% Define IIR filter function
function y = IIRfilter(x, theta, r)
    N = length(x);
    y = zeros(1, N); % Initialize output
    for n = 1:N
        y(n) = (1 - r) * x(n); % Apply x(n) to output
        if n > 1
            y(n) = y(n) + 2 * r * cos(theta) * y(n-1);
        end
        if n > 2
            y(n) = y(n) - r^2 * y(n-2);
        end
    end
end

% Apply the filter to pcm signal
r = 0.99999;
filtered_pcm = IIRfilter(pcm, theta, r);

% Plot time domain samples for indices 100 to 200 of the filtered signal
figure;
subplot(2, 1, 1);
plot(100:200, filtered_pcm(100:200));
title('Filtered pcm Signal (Time Domain)');
xlabel('Sample Index');
ylabel('Amplitude');
grid on;
    set(gca, 'FontSize', 15);


% Calculate and plot DTFT for the filtered signal over indices 100 to 1100
[Y, w] = DTFT(filtered_pcm(100:1100), N);
subplot(2, 1, 2);
plot(w, abs(Y));
title('Magnitude of DTFT for Filtered Signal');
xlabel('Frequency (rad/sample)');
ylabel('|Y(\omega)|');
xlim([-pi pi]);
grid on;
    set(gca, 'FontSize', 15);


% Zoom into DTFT around [theta - 0.02, theta + 0.02]
theta_range = [theta - 0.02, theta + 0.02];
figure;
plot(w, abs(Y));
title('Zoomed Magnitude of DTFT Around \theta');
xlabel('Frequency (rad/sample)');
ylabel('|Y(\omega)|');
xlim(theta_range);
grid on;
    set(gca, 'FontSize', 15);
