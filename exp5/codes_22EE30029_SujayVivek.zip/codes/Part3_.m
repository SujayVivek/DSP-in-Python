% Parameters
theta = pi / 3;      % Given theta value
r_values = [0.99, 0.9, 0.7];  % Different r values

% Frequency vector for plotting
w = linspace(-pi, pi, 1000);
figure;

for i = 1:length(r_values)
    r = r_values(i);
    
    % Frequency response calculation |Hi(e^jw)|
    H_i = (1 - r) ./ (1 - 2 * r * cos(theta) * exp(-1j * w) + r^2 * exp(-2j * w));
    H_i_mag = abs(H_i);
    
    % Subplot for each r value
    subplot(3, 1, i);
    plot(w, H_i_mag, 'LineWidth', 1.5);
    title(['Magnitude of Frequency Response for r = ', num2str(r)]);
    xlabel('Frequency (\omega)');
    ylabel('|H_i(e^{j\omega})|');
    set(gca, 'FontSize', 15);
    grid on;
end

% Global plot adjustments
sgtitle('Sujay Vivek 22EE30029');
