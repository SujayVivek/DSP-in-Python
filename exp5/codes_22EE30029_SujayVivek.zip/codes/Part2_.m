% Load the audio signal
load nspeech1.mat;

% Extract a portion of the signal from indices 100 to 200
sampleIndices = 100:200;
signalSegment = nspeech1(sampleIndices);

% Plot the signal segment
figure;
subplot(1,1,1)
plot(sampleIndices, signalSegment);
title('Time Domain Plot of Original Signal (101 samples)');
xlabel('Sample Index');
ylabel('Amplitude');
sgtitle('Name: Sujay Vivek - Roll No: 22EE30029')
set(gca, 'FontSize', 15);
%Creating a DTFT Function
function [X, w] = DTFT(x, M)
    N = length(x);       % Length of the input signal
    if M == 0
        M = N;           % If M is not specified, set it equal to the length of x
    end
    w = linspace(-pi, pi, M);  % Frequency points from -pi to pi
    X = zeros(1, M);           % Initialize the DTFT output
    
    % Calculate the DTFT over each frequency
    for k = 1:M
        X(k) = sum(x .* exp(-1j * w(k) * (0:N-1))); 
    end
end



% Define the range of samples
dtftIndices = 100:1100;
x = nspeech1(dtftIndices);

% Compute the DTFT
[X, w] = DTFT(x, 0); 

% Plot the magnitude of the DTFT
figure;
subplot(1,1,1);
sgtitle('Name: Sujay Vivek - Roll No: 22EE30029');
plot(w, abs(X));
title('Magnitude of DTFT for 1001 samples');
xlabel('Frequency (\omega)');
ylabel('|X(\omega)|');
set(gca, 'FontSize', 15);

%TO FIND THE MAXIMUM FREQUENCY
[Xmax, Imax] = max(abs(X));
theta = w(Imax);  % Extract the frequency corresponding to the max value

figure;
plot(w, abs(X));
title('Magnitude of DTFT for 1001 samples');
xlabel('Frequency (\omega)');
ylabel('|X(\omega)|');
grid on;

% Display theta and max frequency value on the plot
str = sprintf('Max |X(\\omega)| = %.2f\n\\theta = %.4f rad/s', Xmax, theta);
text(theta, Xmax, str, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right', 'FontSize', 10, 'FontWeight', 'bold');

% Highlight the max point with a marker
hold on;
plot(theta, Xmax, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
set(gca, 'FontSize', 15);


%FINDING THE FIR FILTER

function y = FIRfilter(x)
    % FIR filter that implements H_f(z) based on theta
      % Use the value calculated above
      theta = 1.3258;
    b = [1, -2*cos(theta), 1];  % FIR filter coefficients
    a = 1;  % FIR filter has all-zero coefficients in the denominator

    % Filter the signal using convolution
    y = filter(b, a, x);
end

% Apply the FIRfilter to the signal
filteredSignal = FIRfilter(nspeech1);

% Plot the filtered signal segment (100 to 200 samples)
figure;
subplot(1,1,1);
sgtitle('Name: Sujay Vivek - Roll No: 22EE30029');
plot(sampleIndices, filteredSignal(sampleIndices));
title('Time Domain Plot of Filtered Signal (101 samples)');
xlabel('Sample Index');
ylabel('Amplitude');
set(gca, 'FontSize', 15);

%DTFT OF THE FILTERED SIGNAL

[X_filtered, w_filtered] = DTFT(filteredSignal(dtftIndices), 0);

% Plot the magnitude of the DTFT for the filtered signal
figure;
subplot(1,1,1);
sgtitle('Name: Sujay Vivek - Roll No: 22EE30029');
plot(w_filtered, abs(X_filtered));
title('Magnitude of DTFT for Filtered Signal (1001 samples)');
xlabel('Frequency (\omega)');
ylabel('|X_{filtered}(\omega)|');
set(gca, 'FontSize', 15);